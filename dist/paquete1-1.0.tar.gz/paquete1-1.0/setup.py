from setuptools import setup

setup (
    name="paquete1",
    version="1.0",
    author="Nicolas Algranti",
    author_email="nicolasalgranti@gmail.com",

    packages=["paquete1"],
)